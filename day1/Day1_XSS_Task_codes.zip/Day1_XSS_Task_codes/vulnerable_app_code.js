const express = require('express');
const app = express();
const PORT = 3000;

const products = [
    { id: 1, name: "Apple Juice", price: "$1.99" },
    { id: 2, name: "Orange Juice", price: "$2.49" },
    { id: 3, name: "Eggfruit Juice", price: "$8.99" }
];

app.get('/search', (req, res) => {
    const query = req.query.q || '';
    res.send(`
        <!DOCTYPE html>
        <html>
        <head><title>OWASP Juice Shop - Search</title></head>
        <body style="font-family: Arial; padding: 30px;">
            <h2>OWASP Juice Shop Sandbox (Day 1)</h2>
            <form action="/search" method="GET">
                <input type="text" name="q" value="${query.replace(/"/g, '&quot;')}" placeholder="Search...">
                <button type="submit">Search</button>
            </form>
            <div style="margin-top: 20px; padding: 15px; background: #ffebee;">
                <h3>Search results for: ${query}</h3>
            </div>
            <ul>${products.map(p => `<li>${p.name} - ${p.price}</li>`).join('')}</ul>
        </body>
        </html>
    `);
});

app.listen(PORT, () => console.log(`Vulnerable App Running: http://localhost:${PORT}/search`));