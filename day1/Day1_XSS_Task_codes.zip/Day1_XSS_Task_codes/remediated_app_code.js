const express = require('express');
const app = express();
const PORT = 3001;

function htmlEncode(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

app.get('/search', (req, res) => {
    const rawQuery = req.query.q || '';
    const safeQuery = htmlEncode(rawQuery);
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self';");

    res.send(`
        <!DOCTYPE html>
        <html>
        <head><title>OWASP Juice Shop - Secure Search</title></head>
        <body style="font-family: Arial; padding: 30px;">
            <h2>OWASP Juice Shop (Remediated Endpoint)</h2>
            <form action="/search" method="GET">
                <input type="text" name="q" value="${safeQuery}">
                <button type="submit">Search</button>
            </form>
            <div style="margin-top: 20px; padding: 15px; background: #e8f5e9;">
                <h3>Search results for: ${safeQuery}</h3>
            </div>
        </body>
        </html>
    `);
});

app.listen(PORT, () => console.log(`Secure App Running: http://localhost:${PORT}/search`));