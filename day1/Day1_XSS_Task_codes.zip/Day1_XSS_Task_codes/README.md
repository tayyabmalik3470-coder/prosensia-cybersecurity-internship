# Security Task Force - Day 1 Submission (XSS Vulnerability & Remediation)

## Project Setup
1. Open terminal in this folder and install dependencies:
   npm install

2. Run Vulnerable Application:
   node vulnerable_app_code.js
   
   - Test Link in Browser:
     http://localhost:3000/search?q=<img src=x onerror=alert('XSS')>
   - Result: Triggered XSS Alert popup.

3. Run Remediated (Secure) Application:
   node remediated_app.js
   
   - Test Link in Browser:
     http://localhost:3001/search?q=<img src=x onerror=alert('XSS')>
   - Result: Input sanitized with output encoding & CSP header (No XSS execution).